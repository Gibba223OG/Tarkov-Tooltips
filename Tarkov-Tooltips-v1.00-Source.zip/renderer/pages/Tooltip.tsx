import React, { useMemo, useState, useEffect } from "react";
import { TOOLTIP_ITEM } from "../state/tooltipItem";
import { useHookstate } from "@hookstate/core";
import { numberWithCommas } from "../../utils";
import { ItemTask } from "../../models/Item";

const itemsToKeep = [
  {
    name: "WI-FI Camera",
    quantity: 4,
    task: "Provide Viewership",
    inRaid: false,
  },
  {
    name: "AK-50 M-LOK handguard with gas tube",
    quantity: 1,
    task: "Fair Price - Part 2",
    inRaid: false,
  },
  {
    name: "Gas analyzer",
    quantity: 1,
    task: "Sanitary Standards - Part 1",
    inRaid: true,
  },
  {
    name: "Dorm room 206 key",
    quantity: 1,
    task: "Operation Aquarius - Part 1",
    inRaid: false,
  },
  {
    name: "Bottle of water (0.6L)",
    quantity: 5,
    task: "Easy Money - Part 2",
    inRaid: true,
  },
  {
    name: "Pack of Tarker dried meat",
    quantity: 5,
    task: "Easy Money - Part 2",
    inRaid: true,
  },
  {
    name: "SVDS 7.62x54R sniper rifle",
    quantity: 4,
    task: "Make Amends - Equipment",
    inRaid: true,
  },
  {
    name: "Metal fuel tank",
    quantity: 2,
    task: "Rite of Passage",
    inRaid: true,
  },
  {
    name: "MP-133 12ga pump-action shotgun",
    quantity: 2,
    task: "Debut",
    inRaid: false,
  },
  {
    name: "MP-133 12ga pump-action shotgun",
    quantity: 1,
    task: "Gunsmith - Part 1",
    inRaid: false,
  },
  {
    name: "BNTI Module-3M body armor",
    quantity: 1,
    task: "Supplier",
    inRaid: true,
  },
  {
    name: "TOZ-106 20ga bolt-action shotgun",
    quantity: 1,
    task: "Supplier",
    inRaid: true,
  },
  {
    name: "Secure Flash drive V3",
    quantity: 1,
    task: "Make Amends",
    inRaid: true,
  },
  {
    name: "Steyr AUG A1 5.56x45 assault rifle",
    quantity: 1,
    task: "Balancing - Part 1",
    inRaid: false,
  },
  {
    name: "Lobaev Arms DVL-10 7.62x51 bolt-action sniper rifle",
    quantity: 1,
    task: "Break the Deal",
    inRaid: false,
  },
  {
    name: "DVL-10 7.62x51 10-round magazine",
    quantity: 1,
    task: "Break the Deal",
    inRaid: false,
  },
  {
    name: "ELCAN SpecterDR 1x/4x scope",
    quantity: 1,
    task: "Break the Deal",
    inRaid: false,
  },
  {
    name: "7.62x51mm TCW SP ammo pack (20 pcs)",
    quantity: 1,
    task: "Break the Deal",
    inRaid: false,
  },
  { name: "Unknown key", quantity: 1, task: "The Extortionist", inRaid: false },
  { name: "Toolset", quantity: 2, task: "Farming - Part 1", inRaid: false },
  {
    name: "Primorsky 46-48 skybridge key",
    quantity: 1,
    task: "Ballet Lover",
    inRaid: false,
  },
  {
    name: "Iskra ration pack",
    quantity: 3,
    task: "Acquaintance",
    inRaid: true,
  },
  {
    name: "Pack of instant noodles",
    quantity: 2,
    task: "Acquaintance",
    inRaid: true,
  },
  {
    name: "Can of beef stew (Large)",
    quantity: 2,
    task: "Acquaintance",
    inRaid: true,
  },
  {
    name: "Kalashnikov AKS-74U 5.45x39 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 2",
    inRaid: false,
  },
  {
    name: "Gas analyzer",
    quantity: 2,
    task: "Sanitary Standards - Part 2",
    inRaid: true,
  },
  {
    name: "MS2000 Marker",
    quantity: 3,
    task: "The Blood of War - Part 1",
    inRaid: false,
  },
  {
    name: "PACA Soft Armor",
    quantity: 1,
    task: "Balancing - Part 2",
    inRaid: false,
  },
  {
    name: "Labrys access keycard",
    quantity: 1,
    task: "Forced Alliance",
    inRaid: false,
  },
  {
    name: "Secure Flash drive",
    quantity: 2,
    task: "What's on the Flash Drive?",
    inRaid: true,
  },
  { name: "Bomber beanie", quantity: 1, task: "Dandies", inRaid: false },
  {
    name: "RayBench Hipster Reserve sunglasses",
    quantity: 1,
    task: "Dandies",
    inRaid: false,
  },
  {
    name: "Bottle of Fierce Hatchling moonshine",
    quantity: 1,
    task: "Sensory Analysis - Part 2",
    inRaid: false,
  },
  {
    name: "KOSA UAV electronic jamming device",
    quantity: 1,
    task: "Order From Outside",
    inRaid: true,
  },
  {
    name: "Bottle of Fierce Hatchling moonshine",
    quantity: 1,
    task: "Sensory Analysis - Part 1",
    inRaid: false,
  },
  {
    name: "Crye Precision CPC plate carrier (Goons Edition)",
    quantity: 1,
    task: "Special Offer",
    inRaid: true,
  },
  {
    name: "Mystery Ranch NICE COMM 3 BVS frame system (Coyote)",
    quantity: 1,
    task: "Special Offer",
    inRaid: true,
  },
  {
    name: "LBT-1961A Load Bearing Chest Rig (Goons Edition)",
    quantity: 1,
    task: "Special Offer",
    inRaid: true,
  },
  {
    name: "Crye Precision AVS plate carrier (Tagilla Edition)",
    quantity: 1,
    task: "Special Offer",
    inRaid: true,
  },
  { name: "Sanitar's bag", quantity: 1, task: "Special Offer", inRaid: true },
  {
    name: "Ded Moroz figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "Politician Mutkevich figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "Killa figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "Reshala figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "Ryzhy figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "Scav figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "Tagilla figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "Cultist figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "Den figurine",
    quantity: 1,
    task: "Small Business - Part 1",
    inRaid: true,
  },
  {
    name: "LBT-8005A Day Pack backpack (MultiCam Black)",
    quantity: 50,
    task: "Drip-Out - Part 2",
    inRaid: true,
  },
  {
    name: "HK MP5 9x19 submachine gun (Navy 3 Round Burst)",
    quantity: 1,
    task: "Gunsmith - Part 3",
    inRaid: false,
  },
  { name: "Morphine injector", quantity: 4, task: "Painkiller", inRaid: true },
  {
    name: "Dogtag USEC",
    quantity: 7,
    task: "Friend From the West - Part 1",
    inRaid: false,
  },
  { name: "Power cord", quantity: 2, task: "Farming - Part 2", inRaid: true },
  {
    name: "T-Shaped plug",
    quantity: 4,
    task: "Farming - Part 2",
    inRaid: true,
  },
  {
    name: "Printed circuit board",
    quantity: 2,
    task: "Farming - Part 2",
    inRaid: true,
  },
  {
    name: "Iskra ration pack",
    quantity: 2,
    task: "The Survivalist Path - Thrifty",
    inRaid: false,
  },
  {
    name: "Bottle of water (0.6L)",
    quantity: 2,
    task: "The Survivalist Path - Thrifty",
    inRaid: false,
  },
  {
    name: "OLI logistics department office key",
    quantity: 1,
    task: "Database - Part 2",
    inRaid: false,
  },
  {
    name: "Signal Jammer",
    quantity: 1,
    task: "Broadcast - Part 1",
    inRaid: false,
  },
  {
    name: "Operating room key",
    quantity: 1,
    task: "Broadcast - Part 1",
    inRaid: false,
  },
  {
    name: "Dorm room 303 key",
    quantity: 1,
    task: "Golden Swag",
    inRaid: false,
  },
  {
    name: "Trailer park portable cabin key",
    quantity: 1,
    task: "Golden Swag",
    inRaid: false,
  },
  {
    name: "Tarcone Director's office key",
    quantity: 1,
    task: "Farming - Part 3",
    inRaid: false,
  },
  { name: "MS2000 Marker", quantity: 2, task: "A Fuel Matter", inRaid: false },
  {
    name: "Zulu Nylon Gear M4 Reduced Signature Chest Rig (Ranger Green)",
    quantity: 12,
    task: "Hot Zone",
    inRaid: false,
  },
  {
    name: "Monoclete level III PE ballistic plate",
    quantity: 12,
    task: "Hot Zone",
    inRaid: false,
  },
  {
    name: "Tarcone Director's office key",
    quantity: 1,
    task: "Delivery From the Past",
    inRaid: false,
  },
  {
    name: "Kinda cowboy hat",
    quantity: 2,
    task: "Dressed to Kill",
    inRaid: true,
  },
  {
    name: "Ushanka ear flap hat",
    quantity: 2,
    task: "Dressed to Kill",
    inRaid: true,
  },
  {
    name: "Korund-VM ballistic plates (Front)",
    quantity: 1,
    task: "Surprise",
    inRaid: true,
  },
  {
    name: "SPRTN Omega ballistic plate",
    quantity: 1,
    task: "Surprise",
    inRaid: true,
  },
  {
    name: "6B33 ballistic plate (Front)",
    quantity: 1,
    task: "Surprise",
    inRaid: true,
  },
  {
    name: "LBT-1961A Load Bearing Chest Rig (Goons Edition)",
    quantity: 1,
    task: "Combat Proven",
    inRaid: false,
  },
  {
    name: "Dollars",
    quantity: 5,
    task: "Friend From the West - Part 2",
    inRaid: false,
  },
  {
    name: "Molot Arms Simonov OP-SKS 7.62x39 carbine",
    quantity: 1,
    task: "Gunsmith - Part 4",
    inRaid: false,
  },
  { name: "PC CPU", quantity: 3, task: "Signal - Part 2", inRaid: true },
  {
    name: "Rechargeable battery",
    quantity: 3,
    task: "Signal - Part 2",
    inRaid: true,
  },
  {
    name: "Printed circuit board",
    quantity: 3,
    task: "Signal - Part 2",
    inRaid: true,
  },
  {
    name: "Broken GPhone smartphone",
    quantity: 3,
    task: "Signal - Part 2",
    inRaid: true,
  },
  { name: "Malboro Cigarettes", quantity: 5, task: "Bad Habit", inRaid: true },
  { name: "Strike Cigarettes", quantity: 5, task: "Bad Habit", inRaid: true },
  { name: "Wilston cigarettes", quantity: 5, task: "Bad Habit", inRaid: true },
  { name: "WI-FI Camera", quantity: 2, task: "The Door", inRaid: false },
  {
    name: "TP-200 TNT brick",
    quantity: 3,
    task: "Create a Distraction - Part 1",
    inRaid: false,
  },
  {
    name: "Labrys research notes",
    quantity: 5,
    task: "Hypotheses Testing",
    inRaid: true,
  },
  { name: "MS2000 Marker", quantity: 4, task: "BP Depot", inRaid: false },
  {
    name: "Salty Dog beef sausage",
    quantity: 1,
    task: "The Delicious Sausage",
    inRaid: true,
  },
  {
    name: "SV-98 7.62x54R bolt-action sniper rifle",
    quantity: 1,
    task: "Fishing Gear",
    inRaid: false,
  },
  {
    name: "Leatherman Multitool",
    quantity: 1,
    task: "Fishing Gear",
    inRaid: false,
  },
  {
    name: "Dorm room 220 key",
    quantity: 1,
    task: "Chemical - Part 1",
    inRaid: false,
  },
  {
    name: "Factory emergency exit key",
    quantity: 1,
    task: "Scout",
    inRaid: false,
  },
  { name: "RB-KSM key", quantity: 1, task: "Disease History", inRaid: false },
  { name: "RB-SMP key", quantity: 1, task: "Disease History", inRaid: false },
  {
    name: "Signal Jammer",
    quantity: 3,
    task: "Signal - Part 3",
    inRaid: false,
  },
  { name: "RB-ORB1 key", quantity: 1, task: "Inventory Check", inRaid: false },
  { name: "RB-ORB2 key", quantity: 1, task: "Inventory Check", inRaid: false },
  { name: "RB-ORB3 key", quantity: 1, task: "Inventory Check", inRaid: false },
  { name: "RB-OB key", quantity: 1, task: "Inventory Check", inRaid: false },
  {
    name: "MS2000 Marker",
    quantity: 3,
    task: "Health Care Privacy - Part 1",
    inRaid: false,
  },
  { name: "MS2000 Marker", quantity: 3, task: "Minibus", inRaid: false },
  { name: "MS2000 Marker", quantity: 4, task: "Energy Crisis", inRaid: false },
  {
    name: "Cultist knife",
    quantity: 4,
    task: "Small Business - Part 3",
    inRaid: false,
  },
  {
    name: "Health Resort west wing room 216 key",
    quantity: 1,
    task: "Lend-Lease - Part 1",
    inRaid: false,
  },
  {
    name: "Health Resort east wing room 306 key",
    quantity: 1,
    task: "Lend-Lease - Part 1",
    inRaid: false,
  },
  {
    name: "Health Resort east wing room 308 key",
    quantity: 1,
    task: "Lend-Lease - Part 1",
    inRaid: false,
  },
  {
    name: "Can of beef stew (Small)",
    quantity: 15,
    task: "General Wares",
    inRaid: true,
  },
  { name: "Car battery", quantity: 4, task: "Car Repair", inRaid: true },
  { name: "Spark plug", quantity: 8, task: "Car Repair", inRaid: true },
  {
    name: "WARTECH TV-109 + TV-106 chest rig (A-TACS FG)",
    quantity: 50,
    task: "Drip-Out - Part 1",
    inRaid: true,
  },
  {
    name: "Physical Bitcoin",
    quantity: 15,
    task: "Old Patterns",
    inRaid: false,
  },
  {
    name: "Remington Model 870 12ga pump-action shotgun",
    quantity: 1,
    task: "Gunsmith - Part 5",
    inRaid: false,
  },
  {
    name: "Graphics card",
    quantity: 3,
    task: "Farming - Part 4",
    inRaid: true,
  },
  { name: "CPU fan", quantity: 15, task: "Farming - Part 4", inRaid: true },
  {
    name: "Ski hat with holes for eyes",
    quantity: 1,
    task: "Sew it Good - Part 1",
    inRaid: true,
  },
  {
    name: "Pilgrim tourist backpack",
    quantity: 1,
    task: "Sew it Good - Part 1",
    inRaid: true,
  },
  {
    name: "Health Resort west wing room 306 key",
    quantity: 1,
    task: "Health Care Privacy - Part 2",
    inRaid: false,
  },
  { name: "MS2000 Marker", quantity: 3, task: "Black Swan", inRaid: false },
  {
    name: "MS2000 Marker",
    quantity: 7,
    task: "Abandoned Cargo",
    inRaid: false,
  },
  { name: "MS2000 Marker", quantity: 3, task: "Tigr Safari", inRaid: false },
  {
    name: "Dorm room 220 key",
    quantity: 1,
    task: "Chemical - Part 2",
    inRaid: false,
  },
  {
    name: "Kalashnikov AKM 7.62x39 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 6",
    inRaid: false,
  },
  {
    name: "Pinewood hotel room 215 key",
    quantity: 1,
    task: "Watching You",
    inRaid: false,
  },
  {
    name: "WI-FI Camera",
    quantity: 3,
    task: "Informed Means Armed",
    inRaid: false,
  },
  {
    name: "BNTI Gzhel-K body armor",
    quantity: 2,
    task: "Sew it Good - Part 2",
    inRaid: false,
  },
  {
    name: "Virtex programmable processor",
    quantity: 2,
    task: "Lend-Lease - Part 2",
    inRaid: true,
  },
  {
    name: "Military COFDM Wireless Signal Transmitter",
    quantity: 1,
    task: "Lend-Lease - Part 2",
    inRaid: true,
  },
  { name: "Bundle of wires", quantity: 5, task: "Fertilizers", inRaid: true },
  { name: "Capacitors", quantity: 5, task: "Fertilizers", inRaid: true },
  { name: "UHF RFID Reader", quantity: 1, task: "Import", inRaid: true },
  {
    name: "VPX Flash Storage Module",
    quantity: 1,
    task: "Import",
    inRaid: true,
  },
  { name: "Ghost balaclava", quantity: 1, task: "Gratitude", inRaid: false },
  { name: "Shemagh (Green)", quantity: 1, task: "Gratitude", inRaid: false },
  {
    name: "RayBench Hipster Reserve sunglasses",
    quantity: 1,
    task: "Gratitude",
    inRaid: false,
  },
  {
    name: "Round frame sunglasses",
    quantity: 1,
    task: "Gratitude",
    inRaid: false,
  },
  {
    name: "Cottage back door key",
    quantity: 1,
    task: "Colleagues - Part 2",
    inRaid: false,
  },
  { name: "MS2000 Marker", quantity: 5, task: "Steady Signal", inRaid: false },
  {
    name: "WI-FI Camera",
    quantity: 3,
    task: "The Walls Have Eyes",
    inRaid: false,
  },
  {
    name: "Metal fuel tank (0/100)",
    quantity: 2,
    task: "Natural Exchange",
    inRaid: false,
  },
  {
    name: "AK-74 5.45x39 6L31 60-round magazine",
    quantity: 3,
    task: "Ice Cream Cones",
    inRaid: true,
  },
  { name: "MS2000 Marker", quantity: 3, task: "Scrap Metal", inRaid: false },
  { name: "RB-ST key", quantity: 1, task: "Surplus Goods", inRaid: false },
  {
    name: "Colt M4A1 5.56x45 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 7",
    inRaid: false,
  },
  {
    name: "Secure Flash drive",
    quantity: 3,
    task: "Shady Business",
    inRaid: true,
  },
  { name: "Golden neck chain", quantity: 9, task: "Chumming", inRaid: false },
  {
    name: "6-STEN-140-M military battery",
    quantity: 1,
    task: "Regulated Materials",
    inRaid: true,
  },
  {
    name: "OFZ 30x165mm shell",
    quantity: 5,
    task: "Regulated Materials",
    inRaid: true,
  },
  {
    name: "6B43 Zabralo-Sh body armor (EMR)",
    quantity: 2,
    task: "Sew it Good - Part 3",
    inRaid: false,
  },
  {
    name: "Propane tank (5L)",
    quantity: 2,
    task: "Thirsty - Breadwinner",
    inRaid: true,
  },
  {
    name: "Fuel conditioner",
    quantity: 4,
    task: "The Blood of War - Part 2",
    inRaid: true,
  },
  {
    name: "Dorm room 203 key",
    quantity: 1,
    task: "Shaking Up the Teller",
    inRaid: false,
  },
  { name: "MS2000 Marker", quantity: 1, task: "Big Customer", inRaid: false },
  {
    name: "MS2000 Marker",
    quantity: 1,
    task: "Out of Curiosity",
    inRaid: false,
  },
  {
    name: "WI-FI Camera",
    quantity: 1,
    task: "Drug Trafficking",
    inRaid: false,
  },
  {
    name: "Cultist knife",
    quantity: 1,
    task: "Broadcast - Part 5",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 1,
    task: "Chemical - Part 4",
    inRaid: false,
  },
  {
    name: "Kalashnikov AKS-74N 5.45x39 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 8",
    inRaid: false,
  },
  {
    name: "ORSIS T-5000M 7.62x51 bolt-action sniper rifle",
    quantity: 1,
    task: "Gunsmith - Old Friend's Request",
    inRaid: false,
  },
  {
    name: "PP-19-01 Vityaz 9x19 submachine gun",
    quantity: 1,
    task: "Gunsmith - Old Friend's Request",
    inRaid: false,
  },
  {
    name: "Glock 17 9x19 pistol",
    quantity: 1,
    task: "Gunsmith - Old Friend's Request",
    inRaid: false,
  },
  {
    name: "Health Resort west wing office room 112 key",
    quantity: 1,
    task: "Vitamins - Part 1",
    inRaid: false,
  },
  {
    name: "EMERCOM medical unit key",
    quantity: 1,
    task: "Vitamins - Part 1",
    inRaid: false,
  },
  {
    name: "SV-98 7.62x54R bolt-action sniper rifle",
    quantity: 1,
    task: "Bullshit",
    inRaid: false,
  },
  {
    name: "Roler Submariner gold wrist watch",
    quantity: 1,
    task: "Bullshit",
    inRaid: false,
  },
  {
    name: "Concordia security room key",
    quantity: 1,
    task: "Surveillance",
    inRaid: false,
  },
  {
    name: "Primorsky 46-48 skybridge key",
    quantity: 1,
    task: "Audiophile",
    inRaid: false,
  },
  {
    name: "Peltor ComTac II headset (OD Green)",
    quantity: 2,
    task: "Hot Delivery",
    inRaid: false,
  },
  {
    name: "6B47 Ratnik-BSh helmet (Olive Drab)",
    quantity: 2,
    task: "Hot Delivery",
    inRaid: false,
  },
  {
    name: "BNTI Gzhel-K body armor",
    quantity: 2,
    task: "Hot Delivery",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 3,
    task: "The Blood of War - Part 3",
    inRaid: false,
  },
  {
    name: "Propane tank (5L)",
    quantity: 2,
    task: "Thirsty - Delivery",
    inRaid: false,
  },
  {
    name: "WARTECH TV-109 + TV-106 chest rig (A-TACS FG)",
    quantity: 2,
    task: "Sew it Good - Part 4",
    inRaid: true,
  },
  {
    name: "BlackRock chest rig (Gray)",
    quantity: 2,
    task: "Sew it Good - Part 4",
    inRaid: true,
  },
  {
    name: "Roubles",
    quantity: 400,
    task: "An Apple a Day Keeps the Doctor Away",
    inRaid: false,
  },
  { name: "CMS surgical kit", quantity: 2, task: "Ambulance", inRaid: true },
  {
    name: "Portable defibrillator",
    quantity: 1,
    task: "Ambulance",
    inRaid: true,
  },
  {
    name: 'Gunpowder "Kite"',
    quantity: 3,
    task: "Health Care Privacy - Part 5",
    inRaid: false,
  },
  { name: "Toolset", quantity: 3, task: "Capacity Check", inRaid: false },
  {
    name: "MS2000 Marker",
    quantity: 4,
    task: "Ask for Directions",
    inRaid: false,
  },
  {
    name: "MRE ration pack",
    quantity: 5,
    task: "Humanitarian Supplies",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 2,
    task: "Humanitarian Supplies",
    inRaid: false,
  },
  { name: "MS2000 Marker", quantity: 3, task: "Anesthesia", inRaid: false },
  { name: "Respirator", quantity: 4, task: "Vitamins - Part 2", inRaid: true },
  {
    name: "Medical bloodset",
    quantity: 3,
    task: "Vitamins - Part 2",
    inRaid: true,
  },
  {
    name: "SIG P226R 9x19 pistol",
    quantity: 1,
    task: "Gunsmith - Part 9",
    inRaid: false,
  },
  {
    name: "Bronze lion figurine",
    quantity: 2,
    task: "Living High is Not a Crime - Part 1",
    inRaid: true,
  },
  {
    name: "Horse figurine",
    quantity: 2,
    task: "Living High is Not a Crime - Part 1",
    inRaid: true,
  },
  {
    name: "Cat figurine",
    quantity: 1,
    task: "Living High is Not a Crime - Part 1",
    inRaid: true,
  },
  {
    name: "Roler Submariner gold wrist watch",
    quantity: 1,
    task: "Living High is Not a Crime - Part 1",
    inRaid: true,
  },
  {
    name: "Golden egg",
    quantity: 1,
    task: "Living High is Not a Crime - Part 1",
    inRaid: true,
  },
  { name: "Ophthalmoscope", quantity: 1, task: "Private Clinic", inRaid: true },
  {
    name: "LEDX Skin Transilluminator",
    quantity: 1,
    task: "Private Clinic",
    inRaid: true,
  },
  {
    name: "Aramid fiber fabric",
    quantity: 5,
    task: "Textile - Part 1",
    inRaid: true,
  },
  {
    name: "Ripstop fabric",
    quantity: 10,
    task: "Textile - Part 1",
    inRaid: true,
  },
  { name: "Paracord", quantity: 3, task: "Textile - Part 1", inRaid: true },
  { name: "MS2000 Marker", quantity: 3, task: "Rigged Game", inRaid: false },
  {
    name: "Dorm room 303 key",
    quantity: 1,
    task: "Trust Regain",
    inRaid: false,
  },
  { name: "ZB-014 key", quantity: 1, task: "Trust Regain", inRaid: false },
  {
    name: "Military checkpoint key",
    quantity: 1,
    task: "Trust Regain",
    inRaid: false,
  },
  {
    name: "Gas station storage room key",
    quantity: 1,
    task: "Trust Regain",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 4,
    task: "Revision - Lighthouse",
    inRaid: false,
  },
  {
    name: "Factory emergency exit key",
    quantity: 1,
    task: "Health Care Privacy - Part 6",
    inRaid: false,
  },
  { name: "RB-ST key", quantity: 1, task: "Revision - Reserve", inRaid: false },
  {
    name: "MS2000 Marker",
    quantity: 5,
    task: "Revision - Reserve",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 3,
    task: "Revision - Streets of Tarkov",
    inRaid: false,
  },
  {
    name: "Lower half-mask",
    quantity: 7,
    task: "The Punisher - Part 2",
    inRaid: true,
  },
  { name: "Military cable", quantity: 2, task: "Special Comms", inRaid: false },
  {
    name: "Bulbex cable cutter",
    quantity: 2,
    task: "Special Comms",
    inRaid: false,
  },
  { name: "M67 hand grenade", quantity: 10, task: "No Offence", inRaid: false },
  { name: "Roubles", quantity: 1, task: "Loyalty Buyout", inRaid: false },
  {
    name: "Adrenaline injector",
    quantity: 2,
    task: "Thirsty - Secrets",
    inRaid: true,
  },
  {
    name: "Bottle of OLOLO Multivitamins",
    quantity: 4,
    task: "Thirsty - Secrets",
    inRaid: true,
  },
  {
    name: "Bottle of saline solution",
    quantity: 3,
    task: "Thirsty - Secrets",
    inRaid: true,
  },
  {
    name: "Kalashnikov AK-105 5.45x39 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 10",
    inRaid: false,
  },
  {
    name: "TerraGroup Labs access keycard",
    quantity: 2,
    task: "Fishing Place",
    inRaid: true,
  },
  {
    name: "Fleece fabric",
    quantity: 10,
    task: "Textile - Part 2",
    inRaid: true,
  },
  {
    name: "Cordura polyamide fabric",
    quantity: 10,
    task: "Textile - Part 2",
    inRaid: true,
  },
  {
    name: "KEKTAPE duct tape",
    quantity: 5,
    task: "Textile - Part 2",
    inRaid: true,
  },
  { name: "Portable defibrillator", quantity: 3, task: "Crisis", inRaid: true },
  { name: "Ophthalmoscope", quantity: 3, task: "Crisis", inRaid: true },
  {
    name: "LEDX Skin Transilluminator",
    quantity: 2,
    task: "Crisis",
    inRaid: true,
  },
  { name: "Pile of meds", quantity: 20, task: "Crisis", inRaid: true },
  {
    name: "Bottle of OLOLO Multivitamins",
    quantity: 10,
    task: "Crisis",
    inRaid: true,
  },
  {
    name: "TT-33 7.62x25 TT pistol (Golden)",
    quantity: 1,
    task: "The Huntsman Path - Trophy",
    inRaid: true,
  },
  {
    name: "MS2000 Marker",
    quantity: 2,
    task: "Spa Tour - Part 2",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 1,
    task: "Easy Job - Part 1",
    inRaid: false,
  },
  {
    name: "Dorm room 314 marked key",
    quantity: 1,
    task: "The Cult - Part 2",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 4,
    task: "The Cult - Part 2",
    inRaid: false,
  },
  {
    name: "TDI KRISS Vector Gen.2 9x19 submachine gun",
    quantity: 1,
    task: "Gunsmith - Part 11",
    inRaid: false,
  },
  { name: "Cultist knife", quantity: 12, task: "Night Sweep", inRaid: true },
  {
    name: "Dorm overseer key",
    quantity: 1,
    task: "Against the Conscience - Part 1",
    inRaid: false,
  },
  {
    name: "Bars A-2607 95Kh18 knife",
    quantity: 5,
    task: "The Punisher - Part 4",
    inRaid: true,
  },
  {
    name: "Goshan cash register key",
    quantity: 1,
    task: "Supervisor",
    inRaid: false,
  },
  {
    name: "Antique teapot",
    quantity: 3,
    task: "Living High is Not a Crime - Part 2",
    inRaid: true,
  },
  {
    name: "Antique vase",
    quantity: 2,
    task: "Living High is Not a Crime - Part 2",
    inRaid: true,
  },
  {
    name: "Axel parrot figurine",
    quantity: 1,
    task: "Living High is Not a Crime - Part 2",
    inRaid: true,
  },
  {
    name: "Raven figurine",
    quantity: 2,
    task: "Living High is Not a Crime - Part 2",
    inRaid: true,
  },
  {
    name: "WD-40 (100ml)",
    quantity: 1,
    task: "Spa Tour - Part 3",
    inRaid: true,
  },
  {
    name: "Clin window cleaner",
    quantity: 2,
    task: "Spa Tour - Part 3",
    inRaid: true,
  },
  {
    name: "Corrugated hose",
    quantity: 2,
    task: "Spa Tour - Part 3",
    inRaid: true,
  },
  { name: "Ox bleach", quantity: 2, task: "Spa Tour - Part 3", inRaid: true },
  {
    name: "SIG MPX 9x19 submachine gun",
    quantity: 1,
    task: "Gunsmith - Part 12",
    inRaid: false,
  },
  {
    name: "PR-Taran police baton",
    quantity: 1,
    task: "The Huntsman Path - Crooked Cop",
    inRaid: true,
  },
  {
    name: "Corpse room key",
    quantity: 1,
    task: "Keeper's Word",
    inRaid: false,
  },
  { name: "Cultist knife", quantity: 3, task: "Keeper's Word", inRaid: false },
  {
    name: "Health Resort west wing room 219 key",
    quantity: 1,
    task: "Spa Tour - Part 4",
    inRaid: false,
  },
  {
    name: "Health Resort west wing room 220 key",
    quantity: 1,
    task: "Spa Tour - Part 4",
    inRaid: false,
  },
  {
    name: "Kalashnikov AK-74N 5.45x39 assault rifle",
    quantity: 1,
    task: "The Punisher - Part 5",
    inRaid: true,
  },
  {
    name: "Colt M4A1 5.56x45 assault rifle",
    quantity: 1,
    task: "The Punisher - Part 5",
    inRaid: true,
  },
  {
    name: "Makarov PM 9x18PM pistol",
    quantity: 2,
    task: "The Punisher - Part 5",
    inRaid: true,
  },
  {
    name: "Remington R11 RSASS 7.62x51 marksman rifle",
    quantity: 1,
    task: "Gunsmith - Part 13",
    inRaid: false,
  },
  { name: "Dogtag BEAR", quantity: 20, task: "Counteraction", inRaid: true },
  { name: "Dogtag USEC", quantity: 20, task: "Our Own Land", inRaid: false },
  {
    name: "Dorm overseer key",
    quantity: 1,
    task: "Decisions, Decisions",
    inRaid: false,
  },
  {
    name: "Dorm overseer key",
    quantity: 1,
    task: "Between Two Fires",
    inRaid: false,
  },
  {
    name: "Dorm overseer key",
    quantity: 1,
    task: "Surprise Gift",
    inRaid: false,
  },
  {
    name: "Key to the closed premises of the Health Resort",
    quantity: 1,
    task: "Spa Tour - Part 5",
    inRaid: false,
  },
  {
    name: "6-STEN-140-M military battery",
    quantity: 1,
    task: "Battery Change",
    inRaid: false,
  },
  {
    name: "Dogtag BEAR",
    quantity: 7,
    task: "The Punisher - Part 6",
    inRaid: false,
  },
  {
    name: "Dogtag USEC",
    quantity: 7,
    task: "The Punisher - Part 6",
    inRaid: false,
  },
  {
    name: "HK 416A5 5.56x45 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 14",
    inRaid: false,
  },
  {
    name: "Bottle of Tarkovskaya vodka",
    quantity: 10,
    task: "Booze",
    inRaid: true,
  },
  {
    name: "Bottle of Dan Jackiel whiskey",
    quantity: 10,
    task: "Booze",
    inRaid: true,
  },
  {
    name: "Canister with purified water",
    quantity: 3,
    task: "Booze",
    inRaid: true,
  },
  {
    name: "Bottle of Pevko Light beer",
    quantity: 20,
    task: "Booze",
    inRaid: true,
  },
  {
    name: "KOSA UAV electronic jamming device",
    quantity: 1,
    task: "Protect the Sky",
    inRaid: true,
  },
  { name: "Lega Medal", quantity: 1, task: "Postponed Reward", inRaid: false },
  { name: "Dollars", quantity: 8, task: "Spa Tour - Part 6", inRaid: false },
  {
    name: "AS VAL 9x39 special assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 15",
    inRaid: false,
  },
  {
    name: "Secure container Epsilon",
    quantity: 1,
    task: "The Choice",
    inRaid: false,
  },
  {
    name: "M.U.L.E. stimulant injector",
    quantity: 1,
    task: "Samples",
    inRaid: true,
  },
  {
    name: "Obdolbos cocktail injector",
    quantity: 1,
    task: "Samples",
    inRaid: true,
  },
  { name: "Meldonin injector", quantity: 1, task: "Samples", inRaid: true },
  {
    name: "AHF1-M stimulant injector",
    quantity: 1,
    task: "Samples",
    inRaid: true,
  },
  {
    name: "P22 (Product 22) stimulant injector",
    quantity: 1,
    task: "Samples",
    inRaid: true,
  },
  {
    name: "L1 (Norepinephrine) injector",
    quantity: 1,
    task: "Samples",
    inRaid: true,
  },
  {
    name: "3-(b-TG) stimulant injector",
    quantity: 1,
    task: "Samples",
    inRaid: true,
  },
  {
    name: "Morphine injector",
    quantity: 4,
    task: "Spa Tour - Part 7",
    inRaid: true,
  },
  {
    name: "Alkaline cleaner for heat exchangers",
    quantity: 2,
    task: "Spa Tour - Part 7",
    inRaid: true,
  },
  {
    name: "Corrugated hose",
    quantity: 2,
    task: "Spa Tour - Part 7",
    inRaid: true,
  },
  {
    name: "Propane tank (5L)",
    quantity: 2,
    task: "Spa Tour - Part 7",
    inRaid: true,
  },
  {
    name: "Lobaev Arms DVL-10 7.62x51 bolt-action sniper rifle",
    quantity: 1,
    task: "Gunsmith - Part 16",
    inRaid: false,
  },
  {
    name: "BOSS cap",
    quantity: 1,
    task: "The Huntsman Path - Factory Chief",
    inRaid: true,
  },
  {
    name: "Health Resort east wing room 306 key",
    quantity: 1,
    task: "Cargo X - Part 1",
    inRaid: false,
  },
  {
    name: "Health Resort east wing room 308 key",
    quantity: 1,
    task: "Cargo X - Part 1",
    inRaid: false,
  },
  {
    name: "Health Resort office key with a blue tape",
    quantity: 1,
    task: "Chemistry Closet",
    inRaid: false,
  },
  {
    name: "Kalashnikov AK-102 5.56x45 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 17",
    inRaid: false,
  },
  {
    name: "Shturman's stash key",
    quantity: 1,
    task: "The Huntsman Path - Woods Keeper",
    inRaid: true,
  },
  {
    name: "MS2000 Marker",
    quantity: 1,
    task: "Wet Job - Part 2",
    inRaid: false,
  },
  {
    name: "Kalashnikov AKMN 7.62x39 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 18",
    inRaid: false,
  },
  { name: "Dogtag BEAR", quantity: 20, task: "Trophies", inRaid: true },
  { name: "Dogtag USEC", quantity: 20, task: "Trophies", inRaid: true },
  {
    name: "SVDS 7.62x54R sniper rifle",
    quantity: 1,
    task: "Gunsmith - Part 19",
    inRaid: false,
  },
  {
    name: "Trijicon REAP-IR thermal scope",
    quantity: 2,
    task: "The Courier",
    inRaid: false,
  },
  {
    name: "VPX Flash Storage Module",
    quantity: 5,
    task: "Special Equipment",
    inRaid: true,
  },
  {
    name: "UHF RFID Reader",
    quantity: 5,
    task: "Special Equipment",
    inRaid: true,
  },
  {
    name: "Virtex programmable processor",
    quantity: 5,
    task: "Special Equipment",
    inRaid: true,
  },
  {
    name: "Military COFDM Wireless Signal Transmitter",
    quantity: 5,
    task: "Special Equipment",
    inRaid: true,
  },
  {
    name: "Military flash drive",
    quantity: 4,
    task: "Special Equipment",
    inRaid: true,
  },
  {
    name: "MS2000 Marker",
    quantity: 1,
    task: "Cargo X - Part 4",
    inRaid: false,
  },
  {
    name: "TerraGroup Labs access keycard",
    quantity: 10,
    task: "Colleagues - Part 3",
    inRaid: true,
  },
  {
    name: "AHF1-M stimulant injector",
    quantity: 1,
    task: "Colleagues - Part 3",
    inRaid: true,
  },
  {
    name: "3-(b-TG) stimulant injector",
    quantity: 1,
    task: "Colleagues - Part 3",
    inRaid: true,
  },
  {
    name: "Springfield Armory M1A 7.62x51 rifle",
    quantity: 1,
    task: "Gunsmith - Part 20",
    inRaid: false,
  },
  {
    name: "Maska-1SCh bulletproof helmet (Killa Edition)",
    quantity: 1,
    task: "The Huntsman Path - Sellout",
    inRaid: true,
  },
  {
    name: "Health Resort east wing room 328 key",
    quantity: 1,
    task: "Wet Job - Part 5",
    inRaid: false,
  },
  { name: "Euros", quantity: 50, task: "Mentor", inRaid: false },
  {
    name: "Remington Model 700 7.62x51 bolt-action sniper rifle",
    quantity: 1,
    task: "Gunsmith - Part 21",
    inRaid: false,
  },
  {
    name: "Colt M1911A1 .45 ACP pistol",
    quantity: 1,
    task: "Gunsmith - Part 21",
    inRaid: false,
  },
  {
    name: "RSP-30 reactive signal cartridge (Yellow)",
    quantity: 2,
    task: "The Price of Independence",
    inRaid: false,
  },
  {
    name: "Colt M4A1 5.56x45 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 22",
    inRaid: false,
  },
  {
    name: "CMMG Mk47 Mutant 7.62x39 assault rifle",
    quantity: 1,
    task: "Gunsmith - Part 23",
    inRaid: false,
  },
  {
    name: "Knight's Armament Company SR-25 7.62x51 marksman rifle",
    quantity: 1,
    task: "Gunsmith - Part 24",
    inRaid: false,
  },
  {
    name: "Kalashnikov PKP 7.62x54R infantry machine gun",
    quantity: 1,
    task: "Gunsmith - Part 25",
    inRaid: false,
  },
  {
    name: "Keycard with a blue marking",
    quantity: 1,
    task: "TerraGroup Employee",
    inRaid: false,
  },
  {
    name: "Electronic components",
    quantity: 4,
    task: "Network Provider - Part 1",
    inRaid: true,
  },
  {
    name: "Military COFDM Wireless Signal Transmitter",
    quantity: 4,
    task: "Network Provider - Part 1",
    inRaid: true,
  },
  {
    name: "Gas analyzer",
    quantity: 4,
    task: "Network Provider - Part 1",
    inRaid: true,
  },
  {
    name: "Broken GPhone smartphone",
    quantity: 4,
    task: "Network Provider - Part 1",
    inRaid: true,
  },
  {
    name: "Radio repeater",
    quantity: 4,
    task: "Network Provider - Part 2",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 4,
    task: "Assessment - Part 2",
    inRaid: false,
  },
  {
    name: "SJ1 TGLabs combat stimulant injector",
    quantity: 15,
    task: "Assessment - Part 3",
    inRaid: true,
  },
  {
    name: "SJ6 TGLabs combat stimulant injector",
    quantity: 5,
    task: "Assessment - Part 3",
    inRaid: true,
  },
  {
    name: "SJ9 TGLabs combat stimulant injector",
    quantity: 1,
    task: "Assessment - Part 3",
    inRaid: true,
  },
  {
    name: "Piece of plexiglass",
    quantity: 2,
    task: "Key to the Tower",
    inRaid: true,
  },
  {
    name: "Insulating tape",
    quantity: 1,
    task: "Key to the Tower",
    inRaid: true,
  },
  {
    name: "Military circuit board",
    quantity: 2,
    task: "Key to the Tower",
    inRaid: true,
  },
  {
    name: "Military COFDM Wireless Signal Transmitter",
    quantity: 1,
    task: "Key to the Tower",
    inRaid: true,
  },
  { name: "Working LCD", quantity: 1, task: "Key to the Tower", inRaid: true },
  {
    name: "Digital secure DSP radio transmitter",
    quantity: 1,
    task: "Knock-Knock",
    inRaid: false,
  },
  {
    name: "Digital secure DSP radio transmitter",
    quantity: 1,
    task: "Getting Acquainted",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 2,
    task: "Information Source",
    inRaid: false,
  },
  {
    name: "Radar station commandant room key",
    quantity: 1,
    task: "Top Secret",
    inRaid: false,
  },
  { name: "RB-ST key", quantity: 1, task: "Snatch", inRaid: false },
  {
    name: 'TerraGroup "Blue Folders" materials',
    quantity: 2,
    task: "Return the Favor",
    inRaid: false,
  },
  {
    name: "RSP-30 reactive signal cartridge (Yellow)",
    quantity: 1,
    task: "Payback",
    inRaid: false,
  },
  {
    name: "ASh-12 12.7x55 assault rifle",
    quantity: 1,
    task: "Provocation",
    inRaid: false,
  },
  {
    name: "Salty Dog beef sausage",
    quantity: 1,
    task: "Provocation",
    inRaid: false,
  },
  {
    name: "Bottle of Fierce Hatchling moonshine",
    quantity: 1,
    task: "Provocation",
    inRaid: false,
  },
  { name: "Toilet paper", quantity: 1, task: "Provocation", inRaid: false },
  {
    name: "Kiba Arms outer door key",
    quantity: 1,
    task: "Provocation",
    inRaid: false,
  },
  {
    name: "Kiba Arms inner grate door key",
    quantity: 1,
    task: "Provocation",
    inRaid: false,
  },
  {
    name: "Object #21WS keycard",
    quantity: 2,
    task: "Provocation",
    inRaid: false,
  },
  {
    name: "TerraGroup Labs weapon testing area key",
    quantity: 1,
    task: "Following the Bread Crumbs",
    inRaid: false,
  },
  {
    name: "TerraGroup Labs keycard (Black)",
    quantity: 1,
    task: "Following the Bread Crumbs",
    inRaid: false,
  },
  {
    name: "TerraGroup Labs manager's office room key",
    quantity: 1,
    task: "Following the Bread Crumbs",
    inRaid: false,
  },
  {
    name: "Primorsky 46-48 skybridge key",
    quantity: 1,
    task: "Spotter",
    inRaid: false,
  },
  {
    name: "AI .338 LM Tactical Sound Moderator",
    quantity: 1,
    task: "Spotter",
    inRaid: false,
  },
  {
    name: "Trijicon REAP-IR thermal scope",
    quantity: 1,
    task: "Spotter",
    inRaid: false,
  },
  {
    name: "MS2000 Marker",
    quantity: 1,
    task: "Trouble in the Big City",
    inRaid: false,
  },
  {
    name: "RSP-30 reactive signal cartridge (Yellow)",
    quantity: 1,
    task: "Trouble in the Big City",
    inRaid: false,
  },
  {
    name: "Augmentin antibiotic pills",
    quantity: 3,
    task: "First in Line",
    inRaid: true,
  },
  {
    name: "WI-FI Camera",
    quantity: 27,
    task: "Is This a Reference?",
    inRaid: false,
  },
  { name: "Salewa first aid kit", quantity: 3, task: "Shortage", inRaid: true },
  { name: "Euros", quantity: 50, task: "Fair Price - Part 1", inRaid: false },
  {
    name: "TheAKGuy AK-50 .50 BMG sniper rifle",
    quantity: 1,
    task: "Hobby Club",
    inRaid: false,
  },
  { name: "Classic matches", quantity: 2, task: "Heating 1", inRaid: false },
  {
    name: "Crickent lighter",
    quantity: 1,
    task: "Illumination 1",
    inRaid: false,
  },
  { name: "Toilet paper", quantity: 1, task: "Lavatory 1", inRaid: false },
  { name: "Toothpaste", quantity: 1, task: "Lavatory 1", inRaid: false },
  { name: "Soap", quantity: 1, task: "Lavatory 1", inRaid: false },
  { name: "Awl", quantity: 1, task: "Lavatory 1", inRaid: false },
  {
    name: "Disposable syringe",
    quantity: 1,
    task: "Medstation 1",
    inRaid: false,
  },
  { name: "Pile of meds", quantity: 1, task: "Medstation 1", inRaid: false },
  { name: "Aseptic bandage", quantity: 2, task: "Medstation 1", inRaid: false },
  {
    name: "Bottle of OLOLO Multivitamins",
    quantity: 1,
    task: "Medstation 1",
    inRaid: false,
  },
  {
    name: "Construction measuring tape",
    quantity: 1,
    task: "Security 1",
    inRaid: false,
  },
  { name: "Screw nuts", quantity: 2, task: "Workbench 1", inRaid: false },
  { name: "Bolts", quantity: 2, task: "Workbench 1", inRaid: false },
  {
    name: "Leatherman Multitool",
    quantity: 1,
    task: "Workbench 1",
    inRaid: false,
  },
  {
    name: "WI-FI Camera",
    quantity: 1,
    task: "Cultist Circle 1",
    inRaid: false,
  },
  {
    name: "Construction measuring tape",
    quantity: 1,
    task: "Cultist Circle 1",
    inRaid: true,
  },
  {
    name: "SurvL Survivor Lighter",
    quantity: 1,
    task: "Cultist Circle 1",
    inRaid: true,
  },
  {
    name: "Can of white salt",
    quantity: 3,
    task: "Cultist Circle 1",
    inRaid: true,
  },
  { name: "Light bulb", quantity: 5, task: "Cultist Circle 1", inRaid: true },
  {
    name: "PAID AntiRoach spray",
    quantity: 1,
    task: "Cultist Circle 1",
    inRaid: true,
  },
  { name: "Spark plug", quantity: 1, task: "Generator 1", inRaid: false },
  {
    name: "Phase control relay",
    quantity: 2,
    task: "Nutrition Unit 1",
    inRaid: false,
  },
  { name: "Power cord", quantity: 1, task: "Nutrition Unit 1", inRaid: false },
  {
    name: "Can of white salt",
    quantity: 1,
    task: "Nutrition Unit 1",
    inRaid: false,
  },
  { name: "Duct tape", quantity: 1, task: "Rest Space 1", inRaid: false },
  { name: "Classic matches", quantity: 1, task: "Rest Space 1", inRaid: false },
  { name: "Screw nuts", quantity: 1, task: "Shooting Range 1", inRaid: false },
  { name: "Bolts", quantity: 1, task: "Shooting Range 1", inRaid: false },
  {
    name: "Metal spare parts",
    quantity: 1,
    task: "Shooting Range 1",
    inRaid: false,
  },
  {
    name: "Corrugated hose",
    quantity: 4,
    task: "Water Collector 1",
    inRaid: false,
  },
  { name: "Bolts", quantity: 5, task: "Water Collector 1", inRaid: false },
  { name: "Screw nuts", quantity: 5, task: "Water Collector 1", inRaid: false },
  { name: "Duct tape", quantity: 3, task: "Water Collector 1", inRaid: false },
  { name: "CPU fan", quantity: 15, task: "Bitcoin Farm 1", inRaid: false },
  {
    name: "Power supply unit",
    quantity: 10,
    task: "Bitcoin Farm 1",
    inRaid: true,
  },
  { name: "Power cord", quantity: 15, task: "Bitcoin Farm 1", inRaid: false },
  {
    name: "VPX Flash Storage Module",
    quantity: 2,
    task: "Bitcoin Farm 1",
    inRaid: false,
  },
  {
    name: "T-Shaped plug",
    quantity: 10,
    task: "Bitcoin Farm 1",
    inRaid: false,
  },
  {
    name: "Intelligence folder",
    quantity: 1,
    task: "Intelligence Center 1",
    inRaid: false,
  },
  {
    name: "Working LCD",
    quantity: 1,
    task: "Intelligence Center 1",
    inRaid: false,
  },
  {
    name: "Power cord",
    quantity: 1,
    task: "Intelligence Center 1",
    inRaid: false,
  },
  {
    name: "Topographic survey maps",
    quantity: 1,
    task: "Intelligence Center 1",
    inRaid: false,
  },
  {
    name: "Factory plan map",
    quantity: 1,
    task: "Intelligence Center 1",
    inRaid: false,
  },
  {
    name: "Bronze lion figurine",
    quantity: 3,
    task: "Scav Case 1",
    inRaid: true,
  },
  { name: "Gold skull ring", quantity: 6, task: "Scav Case 1", inRaid: true },
  {
    name: "Golden neck chain",
    quantity: 8,
    task: "Scav Case 1",
    inRaid: true,
  },
  {
    name: "Roler Submariner gold wrist watch",
    quantity: 4,
    task: "Scav Case 1",
    inRaid: true,
  },
  {
    name: "Bottle of Fierce Hatchling moonshine",
    quantity: 3,
    task: "Scav Case 1",
    inRaid: true,
  },
  {
    name: "Lucky Scav Junk box",
    quantity: 1,
    task: "Scav Case 1",
    inRaid: false,
  },
  {
    name: "Golden rooster figurine",
    quantity: 1,
    task: "Scav Case 1",
    inRaid: true,
  },
  { name: "Horse figurine", quantity: 1, task: "Library 1", inRaid: true },
  { name: "Chainlet", quantity: 2, task: "Library 1", inRaid: true },
  { name: "Tech manual", quantity: 8, task: "Library 1", inRaid: false },
  { name: "Diary", quantity: 5, task: "Library 1", inRaid: false },
  { name: "Slim diary", quantity: 5, task: "Library 1", inRaid: false },
  { name: "BakeEzy cook book", quantity: 1, task: "Library 1", inRaid: true },
  { name: "Hand drill", quantity: 1, task: "Weapon Rack 1", inRaid: true },
  {
    name: "Metal cutting scissors",
    quantity: 1,
    task: "Weapon Rack 1",
    inRaid: true,
  },
  {
    name: "Energy-saving lamp",
    quantity: 5,
    task: "Weapon Rack 1",
    inRaid: false,
  },
  {
    name: "Xenomorph sealing foam",
    quantity: 5,
    task: "Weapon Rack 1",
    inRaid: false,
  },
  { name: "Bolts", quantity: 15, task: "Weapon Rack 1", inRaid: false },
  {
    name: "Insulating tape",
    quantity: 5,
    task: "Weapon Rack 1",
    inRaid: false,
  },
  { name: "Pack of nails", quantity: 5, task: "Weapon Rack 1", inRaid: false },
  {
    name: "Military power filter",
    quantity: 5,
    task: "Air Filtering Unit 1",
    inRaid: false,
  },
  {
    name: "Gas mask air filter",
    quantity: 5,
    task: "Air Filtering Unit 1",
    inRaid: true,
  },
  {
    name: "Military corrugated tube",
    quantity: 10,
    task: "Air Filtering Unit 1",
    inRaid: false,
  },
  {
    name: "Silicone tube",
    quantity: 10,
    task: "Booze Generator 1",
    inRaid: false,
  },
  {
    name: "Analog thermometer",
    quantity: 2,
    task: "Booze Generator 1",
    inRaid: true,
  },
  {
    name: "Pressure gauge",
    quantity: 2,
    task: "Booze Generator 1",
    inRaid: true,
  },
  {
    name: "Corrugated hose",
    quantity: 10,
    task: "Booze Generator 1",
    inRaid: false,
  },
  {
    name: "Pipe grip wrench",
    quantity: 1,
    task: "Booze Generator 1",
    inRaid: true,
  },
  {
    name: "Radiator helix",
    quantity: 5,
    task: "Booze Generator 1",
    inRaid: false,
  },
  {
    name: "Metal spare parts",
    quantity: 4,
    task: "Booze Generator 1",
    inRaid: false,
  },
  {
    name: "Military cable",
    quantity: 10,
    task: "Solar power 1",
    inRaid: false,
  },
  {
    name: "Phased array element",
    quantity: 6,
    task: "Solar power 1",
    inRaid: false,
  },
  {
    name: "Military power filter",
    quantity: 10,
    task: "Solar power 1",
    inRaid: false,
  },
  { name: "Working LCD", quantity: 3, task: "Solar power 1", inRaid: true },
  {
    name: "Advanced current converter",
    quantity: 1,
    task: "Solar power 1",
    inRaid: false,
  },
  { name: "Round pliers", quantity: 1, task: "Hall of Fame 1", inRaid: true },
  { name: "Fleece fabric", quantity: 5, task: "Hall of Fame 1", inRaid: false },
  { name: "Cat figurine", quantity: 1, task: "Hall of Fame 1", inRaid: true },
  { name: "Light bulb", quantity: 5, task: "Hall of Fame 1", inRaid: false },
  { name: "Pack of nails", quantity: 5, task: "Hall of Fame 1", inRaid: false },
  {
    name: "Insulating tape",
    quantity: 5,
    task: "Hall of Fame 1",
    inRaid: false,
  },
  { name: "Toolset", quantity: 1, task: "Gym 1", inRaid: true },
  { name: "Electric drill", quantity: 1, task: "Gym 1", inRaid: false },
  { name: "Metal cutting scissors", quantity: 1, task: "Gym 1", inRaid: true },
  { name: "Screw nuts", quantity: 5, task: "Gym 1", inRaid: false },
  { name: "Bolts", quantity: 5, task: "Gym 1", inRaid: false },
  { name: "WD-40 (100ml)", quantity: 1, task: "Gym 1", inRaid: false },
  { name: "Insulating tape", quantity: 5, task: "Gym 1", inRaid: false },
  { name: "Hand drill", quantity: 1, task: "Stash 2", inRaid: true },
  { name: "Pack of screws", quantity: 10, task: "Stash 2", inRaid: false },
  { name: "WD-40 (100ml)", quantity: 4, task: "Stash 2", inRaid: false },
  { name: "Pack of nails", quantity: 5, task: "Stash 2", inRaid: true },
  { name: "Electric motor", quantity: 1, task: "Vents 2", inRaid: true },
  { name: "Car battery", quantity: 1, task: "Vents 2", inRaid: true },
  { name: "CPU fan", quantity: 5, task: "Vents 2", inRaid: false },
  { name: "Metal spare parts", quantity: 5, task: "Vents 2", inRaid: false },
  { name: "Hunting matches", quantity: 2, task: "Heating 2", inRaid: true },
  { name: "Dry fuel", quantity: 5, task: "Heating 2", inRaid: false },
  { name: "Crickent lighter", quantity: 5, task: "Heating 2", inRaid: false },
  { name: "Light bulb", quantity: 14, task: "Illumination 2", inRaid: false },
  {
    name: "Bundle of wires",
    quantity: 10,
    task: "Illumination 2",
    inRaid: false,
  },
  {
    name: "Medical bloodset",
    quantity: 2,
    task: "Medstation 2",
    inRaid: true,
  },
  {
    name: "Bottle of saline solution",
    quantity: 6,
    task: "Medstation 2",
    inRaid: false,
  },
  {
    name: "Esmarch tourniquet",
    quantity: 10,
    task: "Medstation 2",
    inRaid: false,
  },
  { name: "Medical tools", quantity: 3, task: "Medstation 2", inRaid: true },
  { name: "DVD drive", quantity: 1, task: "Rest Space 2", inRaid: true },
  { name: "Magnet", quantity: 1, task: "Rest Space 2", inRaid: true },
  {
    name: "Energy-saving lamp",
    quantity: 5,
    task: "Rest Space 2",
    inRaid: false,
  },
  { name: "Pliers Elite", quantity: 1, task: "Security 2", inRaid: true },
  { name: "WD-40 (100ml)", quantity: 2, task: "Security 2", inRaid: false },
  { name: "TP-200 TNT brick", quantity: 2, task: "Security 2", inRaid: false },
  { name: "Corrugated hose", quantity: 6, task: "Lavatory 2", inRaid: false },
  { name: "Pack of screws", quantity: 6, task: "Lavatory 2", inRaid: false },
  { name: "Electric drill", quantity: 1, task: "Lavatory 2", inRaid: true },
  { name: "KEKTAPE duct tape", quantity: 3, task: "Lavatory 2", inRaid: false },
  { name: "Sewing kit", quantity: 2, task: "Lavatory 2", inRaid: true },
  { name: "Wrench", quantity: 4, task: "Nutrition Unit 2", inRaid: false },
  {
    name: "Corrugated hose",
    quantity: 4,
    task: "Nutrition Unit 2",
    inRaid: false,
  },
  {
    name: "Alkaline cleaner for heat exchangers",
    quantity: 2,
    task: "Nutrition Unit 2",
    inRaid: true,
  },
  {
    name: "Phase control relay",
    quantity: 3,
    task: "Nutrition Unit 2",
    inRaid: false,
  },
  {
    name: "Corrugated hose",
    quantity: 6,
    task: "Water Collector 2",
    inRaid: false,
  },
  {
    name: "Electric motor",
    quantity: 2,
    task: "Water Collector 2",
    inRaid: true,
  },
  { name: "Toolset", quantity: 2, task: "Water Collector 2", inRaid: true },
  {
    name: "KEKTAPE duct tape",
    quantity: 5,
    task: "Water Collector 2",
    inRaid: false,
  },
  { name: "Toolset", quantity: 3, task: "Workbench 2", inRaid: true },
  { name: "Electric drill", quantity: 2, task: "Workbench 2", inRaid: true },
  { name: "Bolts", quantity: 10, task: "Workbench 2", inRaid: false },
  { name: "Weapon parts", quantity: 3, task: "Workbench 2", inRaid: false },
  {
    name: 'Set of files "Master"',
    quantity: 1,
    task: "Workbench 2",
    inRaid: true,
  },
  { name: "CPU fan", quantity: 15, task: "Bitcoin Farm 2", inRaid: false },
  {
    name: "Power supply unit",
    quantity: 10,
    task: "Bitcoin Farm 2",
    inRaid: false,
  },
  {
    name: "Printed circuit board",
    quantity: 15,
    task: "Bitcoin Farm 2",
    inRaid: true,
  },
  {
    name: "Phase control relay",
    quantity: 10,
    task: "Bitcoin Farm 2",
    inRaid: false,
  },
  {
    name: "Military power filter",
    quantity: 5,
    task: "Bitcoin Farm 2",
    inRaid: false,
  },
  {
    name: "Leatherman Multitool",
    quantity: 1,
    task: "Gear Rack 1",
    inRaid: false,
  },
  { name: "Fleece fabric", quantity: 10, task: "Gear Rack 1", inRaid: false },
  { name: "Sewing kit", quantity: 1, task: "Gear Rack 1", inRaid: true },
  {
    name: "Energy-saving lamp",
    quantity: 8,
    task: "Gear Rack 1",
    inRaid: false,
  },
  { name: "Bolts", quantity: 15, task: "Gear Rack 1", inRaid: false },
  { name: "Awl", quantity: 1, task: "Gear Rack 1", inRaid: true },
  { name: "Electric drill", quantity: 1, task: "Gear Rack 1", inRaid: true },
  {
    name: "Phase control relay",
    quantity: 10,
    task: "Generator 2",
    inRaid: false,
  },
  { name: "Electric motor", quantity: 1, task: "Generator 2", inRaid: true },
  { name: "Bundle of wires", quantity: 15, task: "Generator 2", inRaid: false },
  {
    name: "Bulbex cable cutter",
    quantity: 1,
    task: "Generator 2",
    inRaid: true,
  },
  { name: "Toolset", quantity: 1, task: "Shooting Range 2", inRaid: true },
  {
    name: "Metal spare parts",
    quantity: 8,
    task: "Shooting Range 2",
    inRaid: false,
  },
  {
    name: "Construction measuring tape",
    quantity: 1,
    task: "Shooting Range 2",
    inRaid: true,
  },
  {
    name: "Bundle of wires",
    quantity: 6,
    task: "Shooting Range 2",
    inRaid: false,
  },
  {
    name: "Pack of screws",
    quantity: 3,
    task: "Shooting Range 2",
    inRaid: false,
  },
  {
    name: "Tube of Poxeram cold welding",
    quantity: 3,
    task: "Shooting Range 2",
    inRaid: false,
  },
  {
    name: "Electric motor",
    quantity: 3,
    task: "Shooting Range 2",
    inRaid: true,
  },
  {
    name: "Energy-saving lamp",
    quantity: 6,
    task: "Shooting Range 2",
    inRaid: false,
  },
  {
    name: "WI-FI Camera",
    quantity: 3,
    task: "Shooting Range 2",
    inRaid: false,
  },
  {
    name: "Electric drill",
    quantity: 1,
    task: "Shooting Range 2",
    inRaid: true,
  },
  { name: "Tech manual", quantity: 1, task: "Hall of Fame 2", inRaid: true },
  { name: "Pliers Elite", quantity: 1, task: "Hall of Fame 2", inRaid: true },
  { name: "Toolset", quantity: 1, task: "Hall of Fame 2", inRaid: true },
  {
    name: "Golden rooster figurine",
    quantity: 1,
    task: "Hall of Fame 2",
    inRaid: true,
  },
  {
    name: "Energy-saving lamp",
    quantity: 10,
    task: "Hall of Fame 2",
    inRaid: false,
  },
  {
    name: "Pack of screws",
    quantity: 6,
    task: "Hall of Fame 2",
    inRaid: false,
  },
  { name: "Duct tape", quantity: 3, task: "Hall of Fame 2", inRaid: false },
  {
    name: "Xenomorph sealing foam",
    quantity: 5,
    task: "Hall of Fame 2",
    inRaid: false,
  },
  {
    name: "Tube of Poxeram cold welding",
    quantity: 2,
    task: "Hall of Fame 2",
    inRaid: false,
  },
  { name: "Wrench", quantity: 1, task: "Gear Rack 2", inRaid: false },
  {
    name: "Aramid fiber fabric",
    quantity: 10,
    task: "Gear Rack 2",
    inRaid: false,
  },
  {
    name: "Energy-saving lamp",
    quantity: 12,
    task: "Gear Rack 2",
    inRaid: false,
  },
  { name: "Pack of nails", quantity: 8, task: "Gear Rack 2", inRaid: false },
  {
    name: "Shustrilo sealing foam",
    quantity: 3,
    task: "Gear Rack 2",
    inRaid: false,
  },
  { name: "Duct tape", quantity: 5, task: "Gear Rack 2", inRaid: false },
  { name: "Electric drill", quantity: 1, task: "Gear Rack 2", inRaid: true },
  { name: "Electric drill", quantity: 1, task: "Weapon Rack 2", inRaid: true },
  {
    name: 'Set of files "Master"',
    quantity: 1,
    task: "Weapon Rack 2",
    inRaid: true,
  },
  {
    name: "Energy-saving lamp",
    quantity: 10,
    task: "Weapon Rack 2",
    inRaid: false,
  },
  {
    name: "Pack of screws",
    quantity: 10,
    task: "Weapon Rack 2",
    inRaid: false,
  },
  { name: "Duct tape", quantity: 10, task: "Weapon Rack 2", inRaid: false },
  {
    name: "Bundle of wires",
    quantity: 10,
    task: "Weapon Rack 2",
    inRaid: false,
  },
  {
    name: "Metal spare parts",
    quantity: 10,
    task: "Weapon Rack 2",
    inRaid: false,
  },
  { name: "Weapon parts", quantity: 5, task: "Weapon Rack 2", inRaid: false },
  {
    name: "Tube of Poxeram cold welding",
    quantity: 3,
    task: "Weapon Rack 2",
    inRaid: false,
  },
  {
    name: "Intelligence folder",
    quantity: 3,
    task: "Intelligence Center 2",
    inRaid: true,
  },
  {
    name: "Secure Flash drive",
    quantity: 3,
    task: "Intelligence Center 2",
    inRaid: false,
  },
  {
    name: "Power cord",
    quantity: 7,
    task: "Intelligence Center 2",
    inRaid: false,
  },
  {
    name: "Damaged hard drive",
    quantity: 8,
    task: "Intelligence Center 2",
    inRaid: false,
  },
  {
    name: 'Set of files "Master"',
    quantity: 1,
    task: "Shooting Range 3",
    inRaid: true,
  },
  {
    name: "Bundle of wires",
    quantity: 10,
    task: "Shooting Range 3",
    inRaid: false,
  },
  {
    name: "Printed circuit board",
    quantity: 5,
    task: "Shooting Range 3",
    inRaid: false,
  },
  {
    name: "Metal spare parts",
    quantity: 5,
    task: "Shooting Range 3",
    inRaid: false,
  },
  { name: "Capacitors", quantity: 5, task: "Shooting Range 3", inRaid: false },
  {
    name: "Phase control relay",
    quantity: 5,
    task: "Shooting Range 3",
    inRaid: false,
  },
  { name: "Power cord", quantity: 5, task: "Shooting Range 3", inRaid: false },
  {
    name: "Leatherman Multitool",
    quantity: 1,
    task: "Shooting Range 3",
    inRaid: false,
  },
  { name: "Tech manual", quantity: 1, task: "Shooting Range 3", inRaid: true },
  { name: "Power cord", quantity: 5, task: "Rest Space 3", inRaid: false },
  { name: "Capacitors", quantity: 5, task: "Rest Space 3", inRaid: false },
  {
    name: "Bundle of wires",
    quantity: 10,
    task: "Rest Space 3",
    inRaid: false,
  },
  {
    name: "GreenBat lithium battery",
    quantity: 4,
    task: "Rest Space 3",
    inRaid: true,
  },
  { name: "Electric motor", quantity: 4, task: "Vents 3", inRaid: true },
  { name: "Bundle of wires", quantity: 14, task: "Vents 3", inRaid: false },
  {
    name: "Printed circuit board",
    quantity: 5,
    task: "Vents 3",
    inRaid: false,
  },
  { name: "Car battery", quantity: 4, task: "Vents 3", inRaid: true },
  { name: "Metal spare parts", quantity: 10, task: "Vents 3", inRaid: false },
  { name: "Capacitors", quantity: 7, task: "Illumination 3", inRaid: true },
  {
    name: "Bundle of wires",
    quantity: 12,
    task: "Illumination 3",
    inRaid: false,
  },
  {
    name: "Energy-saving lamp",
    quantity: 12,
    task: "Illumination 3",
    inRaid: false,
  },
  { name: "Working LCD", quantity: 2, task: "Security 3", inRaid: true },
  { name: "Bundle of wires", quantity: 10, task: "Security 3", inRaid: false },
  { name: "NIXXOR lens", quantity: 8, task: "Security 3", inRaid: false },
  { name: "SSD drive", quantity: 1, task: "Security 3", inRaid: true },
  { name: "Electric drill", quantity: 2, task: "Stash 3", inRaid: true },
  { name: "Pack of screws", quantity: 15, task: "Stash 3", inRaid: false },
  { name: "Pack of nails", quantity: 7, task: "Stash 3", inRaid: true },
  { name: "CPU fan", quantity: 25, task: "Bitcoin Farm 3", inRaid: true },
  {
    name: "Silicone tube",
    quantity: 15,
    task: "Bitcoin Farm 3",
    inRaid: false,
  },
  {
    name: "Electric motor",
    quantity: 10,
    task: "Bitcoin Farm 3",
    inRaid: false,
  },
  {
    name: "Pressure gauge",
    quantity: 10,
    task: "Bitcoin Farm 3",
    inRaid: false,
  },
  {
    name: "6-STEN-140-M military battery",
    quantity: 2,
    task: "Bitcoin Farm 3",
    inRaid: false,
  },
  {
    name: 'Set of files "Master"',
    quantity: 1,
    task: "Hall of Fame 3",
    inRaid: true,
  },
  {
    name: "Electric drill",
    quantity: 1,
    task: "Hall of Fame 3",
    inRaid: true,
  },
  {
    name: "Bronze lion figurine",
    quantity: 1,
    task: "Hall of Fame 3",
    inRaid: true,
  },
  {
    name: "Energy-saving lamp",
    quantity: 15,
    task: "Hall of Fame 3",
    inRaid: false,
  },
  {
    name: "KEKTAPE duct tape",
    quantity: 3,
    task: "Hall of Fame 3",
    inRaid: true,
  },
  { name: "T-Shaped plug", quantity: 6, task: "Hall of Fame 3", inRaid: false },
  {
    name: "Metal spare parts",
    quantity: 15,
    task: "Hall of Fame 3",
    inRaid: false,
  },
  { name: "Power cord", quantity: 5, task: "Hall of Fame 3", inRaid: false },
  { name: "Radiator helix", quantity: 10, task: "Heating 3", inRaid: false },
  { name: "Bundle of wires", quantity: 10, task: "Heating 3", inRaid: false },
  {
    name: "Phase control relay",
    quantity: 4,
    task: "Heating 3",
    inRaid: true,
  },
  {
    name: "Military corrugated tube",
    quantity: 2,
    task: "Heating 3",
    inRaid: true,
  },
  { name: "Corrugated hose", quantity: 10, task: "Lavatory 3", inRaid: false },
  { name: "Pressure gauge", quantity: 2, task: "Lavatory 3", inRaid: true },
  { name: "Toolset", quantity: 1, task: "Lavatory 3", inRaid: true },
  {
    name: "Xenomorph sealing foam",
    quantity: 6,
    task: "Lavatory 3",
    inRaid: false,
  },
  {
    name: "Bottle of saline solution",
    quantity: 10,
    task: "Medstation 3",
    inRaid: false,
  },
  {
    name: "LEDX Skin Transilluminator",
    quantity: 1,
    task: "Medstation 3",
    inRaid: false,
  },
  { name: "Ophthalmoscope", quantity: 1, task: "Medstation 3", inRaid: true },
  { name: "Electric drill", quantity: 1, task: "Weapon Rack 3", inRaid: true },
  {
    name: "Energy-saving lamp",
    quantity: 15,
    task: "Weapon Rack 3",
    inRaid: false,
  },
  {
    name: "Metal spare parts",
    quantity: 10,
    task: "Weapon Rack 3",
    inRaid: false,
  },
  {
    name: "KEKTAPE duct tape",
    quantity: 5,
    task: "Weapon Rack 3",
    inRaid: true,
  },
  {
    name: "Bundle of wires",
    quantity: 15,
    task: "Weapon Rack 3",
    inRaid: false,
  },
  {
    name: "Shustrilo sealing foam",
    quantity: 5,
    task: "Weapon Rack 3",
    inRaid: false,
  },
  { name: "Tech manual", quantity: 1, task: "Weapon Rack 3", inRaid: true },
  {
    name: "#FireKlean gun lube",
    quantity: 1,
    task: "Weapon Rack 3",
    inRaid: true,
  },
  { name: "Pliers Elite", quantity: 2, task: "Workbench 3", inRaid: true },
  {
    name: "#FireKlean gun lube",
    quantity: 1,
    task: "Workbench 3",
    inRaid: true,
  },
  { name: "Can of thermite", quantity: 5, task: "Workbench 3", inRaid: false },
  { name: "Ratchet wrench", quantity: 1, task: "Gear Rack 3", inRaid: true },
  {
    name: 'Set of files "Master"',
    quantity: 1,
    task: "Gear Rack 3",
    inRaid: true,
  },
  {
    name: "Energy-saving lamp",
    quantity: 15,
    task: "Gear Rack 3",
    inRaid: false,
  },
  {
    name: "KEKTAPE duct tape",
    quantity: 10,
    task: "Gear Rack 3",
    inRaid: false,
  },
  {
    name: "Metal spare parts",
    quantity: 15,
    task: "Gear Rack 3",
    inRaid: false,
  },
  {
    name: "Cordura polyamide fabric",
    quantity: 10,
    task: "Gear Rack 3",
    inRaid: false,
  },
  {
    name: "Body armor repair kit",
    quantity: 1,
    task: "Gear Rack 3",
    inRaid: true,
  },
  {
    name: "Phase control relay",
    quantity: 12,
    task: "Generator 3",
    inRaid: false,
  },
  { name: "Electric motor", quantity: 3, task: "Generator 3", inRaid: true },
  { name: "Spark plug", quantity: 16, task: "Generator 3", inRaid: false },
  {
    name: "Power supply unit",
    quantity: 5,
    task: "Generator 3",
    inRaid: true,
  },
  {
    name: "Metal spare parts",
    quantity: 10,
    task: "Generator 3",
    inRaid: false,
  },
  {
    name: "Military COFDM Wireless Signal Transmitter",
    quantity: 2,
    task: "Intelligence Center 3",
    inRaid: true,
  },
  {
    name: "VPX Flash Storage Module",
    quantity: 2,
    task: "Intelligence Center 3",
    inRaid: false,
  },
  {
    name: "Military flash drive",
    quantity: 8,
    task: "Intelligence Center 3",
    inRaid: false,
  },
  {
    name: "Military cable",
    quantity: 8,
    task: "Intelligence Center 3",
    inRaid: false,
  },
  {
    name: "Secure magnetic tape cassette",
    quantity: 2,
    task: "Intelligence Center 3",
    inRaid: false,
  },
  {
    name: "Far-forward GPS Signal Amplifier Unit",
    quantity: 1,
    task: "Intelligence Center 3",
    inRaid: false,
  },
  {
    name: "Pliers Elite",
    quantity: 2,
    task: "Water Collector 3",
    inRaid: true,
  },
  {
    name: "Shustrilo sealing foam",
    quantity: 10,
    task: "Water Collector 3",
    inRaid: false,
  },
  {
    name: "Ratchet wrench",
    quantity: 1,
    task: "Water Collector 3",
    inRaid: true,
  },
  {
    name: "Can of Majaica coffee beans",
    quantity: 5,
    task: "Nutrition Unit 3",
    inRaid: false,
  },
  {
    name: "Pack of sodium bicarbonate",
    quantity: 5,
    task: "Nutrition Unit 3",
    inRaid: false,
  },
  {
    name: "Smoked Chimney drain cleaner",
    quantity: 2,
    task: "Nutrition Unit 3",
    inRaid: true,
  },
  {
    name: "Fierce Blow sledgehammer",
    quantity: 1,
    task: "Defective Wall 4",
    inRaid: true,
  },
  {
    name: "Metal cutting scissors",
    quantity: 1,
    task: "Defective Wall 5",
    inRaid: true,
  },
  { name: "Toolset", quantity: 1, task: "Defective Wall 5", inRaid: true },
  { name: "Bolts", quantity: 10, task: "Stash 4", inRaid: false },
  { name: "Screw nuts", quantity: 10, task: "Stash 4", inRaid: false },
  {
    name: "Shustrilo sealing foam",
    quantity: 8,
    task: "Stash 4",
    inRaid: false,
  },
  { name: "Ratchet wrench", quantity: 2, task: "Stash 4", inRaid: true },
  {
    name: "Corrugated hose",
    quantity: 2,
    task: "Defective Wall 6",
    inRaid: false,
  },
  { name: "Duct tape", quantity: 1, task: "Defective Wall 6", inRaid: false },
  { name: "Toolset", quantity: 1, task: "Defective Wall 6", inRaid: true },
  {
    name: "Pliers Elite",
    quantity: 1,
    task: "Defective Wall 6",
    inRaid: true,
  },
  {
    name: "Metal spare parts",
    quantity: 5,
    task: "Defective Wall 6",
    inRaid: false,
  },
  {
    name: "Xenomorph sealing foam",
    quantity: 1,
    task: "Defective Wall 6",
    inRaid: false,
  },
  {
    name: "Bundle of wires",
    quantity: 2,
    task: "Defective Wall 6",
    inRaid: false,
  },
  { name: "Light bulb", quantity: 2, task: "Defective Wall 6", inRaid: false },
  { name: "Old firesteel", quantity: 1, task: "Collector", inRaid: true },
  { name: "Antique axe", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "Battered antique book",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  { name: "#FireKlean gun lube", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "Golden rooster figurine",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  { name: "Silver Badge", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "Deadlyslob's beard oil",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  {
    name: "Golden 1GPhone smartphone",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  {
    name: "Jar of DevilDog mayo",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  { name: "Can of sprats", quantity: 1, task: "Collector", inRaid: true },
  { name: "Fake mustache", quantity: 1, task: "Collector", inRaid: true },
  { name: "Kotton beanie", quantity: 1, task: "Collector", inRaid: true },
  { name: "Raven figurine", quantity: 1, task: "Collector", inRaid: true },
  { name: "Pestily plague mask", quantity: 1, task: "Collector", inRaid: true },
  { name: "Shroud half-mask", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "Can of Dr. Lupo's coffee beans",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  {
    name: "42 Signature Blend English Tea",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  { name: "Veritas guitar pick", quantity: 1, task: "Collector", inRaid: true },
  { name: "Armband (Evasion)", quantity: 1, task: "Collector", inRaid: true },
  { name: "Can of RatCola soda", quantity: 1, task: "Collector", inRaid: true },
  { name: "Loot Lord plushie", quantity: 1, task: "Collector", inRaid: true },
  { name: "Smoke balaclava", quantity: 1, task: "Collector", inRaid: true },
  { name: "WZ Wallet", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "LVNDMARK's rat poison",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  { name: "Missam forklift key", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "Video cassette with the Cyborg Killer movie",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  { name: "BakeEzy cook book", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "JohnB Liquid DNB glasses",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  { name: "Baddie's red beard", quantity: 1, task: "Collector", inRaid: true },
  { name: "DRD body armor", quantity: 1, task: "Collector", inRaid: true },
  { name: "Gingy keychain", quantity: 1, task: "Collector", inRaid: true },
  { name: "Golden egg", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "Press pass (issued for NoiceGuy)",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  {
    name: "Axel parrot figurine",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  {
    name: "BEAR Buddy plush toy",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  {
    name: "Glorious E lightweight armored mask",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  {
    name: "Inseq gas pipe wrench",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
  { name: "Viibiin sneaker", quantity: 1, task: "Collector", inRaid: true },
  {
    name: "Tamatthi kunai knife replica",
    quantity: 1,
    task: "Collector",
    inRaid: true,
  },
];

export function Tooltip() {
  const tooltipItem = useHookstate(TOOLTIP_ITEM);
  const item = tooltipItem.get();
  const [showOcrDiagnostics, setShowOcrDiagnostics] = useState(false);
  const [showItemName, setShowItemName] = useState(false);
  const [popupBackground, setPopupBackground] = useState("#080909");
  const [popupBorder, setPopupBorder] = useState("#59605a");
  const [popupMainScale, setPopupMainScale] = useState(55);
  const [popupAmmoScale, setPopupAmmoScale] = useState(45);
  const [popupPriceBold, setPopupPriceBold] = useState(true);
  const safeScale = (value: number | undefined, fallback: number) =>
    typeof value === "number" && Number.isFinite(value) && value >= 25 && value <= 100
      ? value : fallback;

  useEffect(() => {
    const loadConfig = async () => {
      try {
        const config = await window.electron.getUserConfig();
        setShowOcrDiagnostics(config.showOcrDiagnostics ?? false);
        setShowItemName(config.showItemName ?? false);
        setPopupBackground(/^#[0-9a-f]{6}$/i.test(config.popupBackground ?? "") ? config.popupBackground : "#080909");
        setPopupBorder(/^#[0-9a-f]{6}$/i.test(config.popupBorder ?? "") ? config.popupBorder : "#59605a");
        setPopupMainScale(safeScale(config.popupMainScale, 55));
        setPopupAmmoScale(safeScale(config.popupAmmoScale, 45));
        setPopupPriceBold(config.popupPriceBold ?? true);
      } catch (error) {
        console.error("Failed to load tooltip config:", error);
      }
    };
    loadConfig();

    // Listen for config changes
    const handleConfigChange = (config: any) => {
      setShowOcrDiagnostics(config.showOcrDiagnostics ?? false);
      setShowItemName(config.showItemName ?? false);
      setPopupBackground(/^#[0-9a-f]{6}$/i.test(config.popupBackground ?? "") ? config.popupBackground : "#080909");
      setPopupBorder(/^#[0-9a-f]{6}$/i.test(config.popupBorder ?? "") ? config.popupBorder : "#59605a");
      setPopupMainScale(safeScale(config.popupMainScale, 55));
      setPopupAmmoScale(safeScale(config.popupAmmoScale, 45));
      setPopupPriceBold(config.popupPriceBold ?? true);
    };

    window.electron.onConfigChanged(handleConfigChange);

    // Cleanup
    return () => {
      // Note: electron.onConfigChanged doesn't provide a cleanup method,
      // but this is fine for a tooltip window lifecycle
    };
  }, []);

  const itemTasks = useMemo(() => {
    return itemsToKeep
      .filter((x) => x?.name === item?.name)
      .map<ItemTask>((x) => {
        return {
          task: x.task,
          count: x.quantity,
          inRaid: x.inRaid,
        };
      });
  }, [item]);

  if (item?.ammoStats) return <AmmoTooltip item={item} background={popupBackground}
    border={popupBorder} zoom={popupAmmoScale / 100} />;

  if (item) {
    const fleaPriceToUse =
      item.prices.avgDay > item.prices.latest
        ? item.prices.latest
        : item.prices.avgDay;
    // The API prices refer to a full item; never divide by the inventory footprint.
    const fleaPrice = fleaPriceToUse;

    return (
      <div
        className="block items-center p-1.5 border rounded-none h-fit w-fit max-w-[540px] text-sm text-[#e4e1d6] font-['Bender_Light'] font-light tracking-wide overflow-visible"
        style={{
          backgroundColor: popupBackground,
          borderColor: popupBorder,
          zoom: popupMainScale / 50, // 50% slider is precisely the historical size.
        }}
      >
        {/* ITEM NAME */}
        {(showItemName || item.unmatched) && (
          <div className="max-w-[510px] whitespace-normal break-words text-[15px]" title={item.name}>
            {item.unmatched ? "No database match" : item.name}
          </div>
        )}
        {showOcrDiagnostics && (
          <div className="max-w-[510px] break-words whitespace-normal text-[11px] text-[#adcdbd]">
            OCR: {item.ocrText || "(empty)"}
            {typeof item.ocrMs === "number" ? " (" + item.ocrMs + " ms)" : ""}
          </div>
        )}

        {!item.unmatched && (
          <>
            {item.availableOnFleaMarket && (
              <div className="whitespace-nowrap">
                <span className="tracking-wider">
                  <span style={{ color: "#abd61c" }}>
                    <span className="font-['Nunito']">₽</span><span style={popupPriceBold
                      ? {fontFamily:"Bender",fontWeight:700} : undefined}>{numberWithCommas(fleaPrice)}</span>
                  </span>
                </span>
              </div>
            )}
            <div className="whitespace-nowrap">
              {item.prices?.trader?.name && item.prices.trader.name !== "N/A"
                ? <span><strong style={{fontFamily:"Bender",fontWeight:700}}>{item.prices.trader.name.charAt(0)}</strong><span className="font-['Nunito']">₽</span></span>
                : <span>Trader unknown</span>}
            </div>
          </>
        )}

        {/* Long quest lists use multiple columns instead of scrolling beyond
            the game window. The native popup grows to fit the rendered card. */}
        <div
          className="gap-x-3"
          style={itemTasks.length > 10 ? {
            display: "grid",
            gridAutoFlow: "column",
            gridTemplateRows: "repeat(" + Math.ceil(itemTasks.length / (itemTasks.length > 20 ? 3 : 2)) + ", auto)",
            gridTemplateColumns: "repeat(" + (itemTasks.length > 20 ? 3 : 2) + ", minmax(0, 1fr))",
          } : undefined}
        >
          {itemTasks.map((task, index) => (
            <TooltipTask key={index} task={task} />
          ))}
        </div>
      </div>
    );
  }

  return <div></div>;
}

function TooltipTask({ task }: { task: ItemTask }) {
  return (
    <div className="flex items-start max-w-[525px] whitespace-normal break-words">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="12"
        height="12"
        viewBox="0 0 24 24"
        fill="none"
        stroke={task.inRaid ? "#e3ae00" : "currentColor"}
        stroke-width="3"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
        <polyline points="22 4 12 14.01 9 11.01" />
      </svg>
      <span className="mx-1"><strong style={{fontFamily:"Bender",fontWeight:700}}>{task.count}</strong> - </span>
      <span className="capitalize min-w-0 break-words">{task.task}</span>
    </div>
  );
}


// Exact v6 HTML cartridge paths and user-approved quantitative mapping.
// This branch replaces the price content ONLY when the API has identified loose ammo.
const AMMO_RATING_LAYOUT: Record<number,{solid:number;faded:number;color:string}> = {
  0:{solid:14,faded:0,color:"#D20603"},
  1:{solid:13,faded:1,color:"#DF3A0C"},
  2:{solid:9,faded:4,color:"#ED6B18"},
  3:{solid:5,faded:4,color:"#FC9D26"},
  4:{solid:3,faded:2,color:"#C1B937"},
  5:{solid:1,faded:2,color:"#86D54D"},
  6:{solid:1,faded:0,color:"#45F165"},
};
function AmmoTooltip({item,background,border,zoom}:{item:any;background:string;border:string;zoom:number}) {
  const stats=item.ammoStats;
  return <div data-pricechecker-ammo="1" className="border rounded-none text-[#e4e1d6] font-['Bender_Light'] font-light tracking-wide"
    style={{padding:"13px 14px 15px",backgroundColor:background,borderColor:border,
      width:"fit-content",maxWidth:583,boxSizing:"border-box",zoom}}>
    <div style={{fontSize:37,lineHeight:1.15,marginBottom:15,overflowWrap:"anywhere"}}>{item.name}</div>
    <div style={{display:"flex",gap:42,alignItems:"baseline",marginBottom:18,whiteSpace:"nowrap",lineHeight:1.12}}>
      {([["DMG",stats.damage],["PEN",stats.penetration]] as [string,number][]).map(([label,value])=>
        <span key={label}>
          <span style={{fontSize:26,letterSpacing:".005em",marginRight:9}}>{label}</span>
          <strong style={{fontSize:36,fontFamily:"Bender",fontWeight:700,color:"#e8ebdf"}}>{value}</strong>
        </span>)}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(6,minmax(0,1fr))",
      width:530,gap:6,alignItems:"center",margin:"1px 0 3px"}}>
      {stats.ratings.map((rating:number,index:number)=>{
        const v=AMMO_RATING_LAYOUT[rating];
        if (!v) return null;
        const total=v.solid+v.faded;
        const perRow=Math.min(total,7);
        const width=perRow>=7?9.4:perRow>=5?12.5:perRow>=4?14:perRow>=3?16:19;
        const height=perRow>=7?31:perRow>=5?39:perRow>=4?42:perRow>=3?49:56;
        const gap=perRow>=7?1.8:perRow>=5?2:3;
        const rows=[Array.from({length:Math.min(total,7)},(_,i)=>i)];
        if (total>7) rows.push(Array.from({length:total-7},(_,i)=>i+7));
        return <div key={index} role="img"
          aria-label={"Armor class "+(index+1)+": rating "+rating+"/6"}
          style={{height:85,display:"flex",alignItems:"center",justifyContent:"center",
            minWidth:0,color:v.color}}>
          <div style={{width:"100%",display:"flex",flexDirection:"column",
            alignItems:total>7?"flex-start":"center",justifyContent:"center",gap:3}}>
            {rows.map((indices,row)=><div key={row} style={{width:"100%",display:"flex",
              justifyContent:total>7?"flex-start":"center",alignItems:"center",gap,whiteSpace:"nowrap"}}>
              {indices.map(i=><svg key={i} viewBox="0 0 24 54" aria-hidden="true"
                style={{width,height,flex:"0 0 auto",display:"block",fill:"currentColor",
                  opacity:i<v.solid?1:0.5}}>
                <path d="M12 0.8 C10.7 2.1 9.2 4.6 8.3 8 L7.8 12.1 Q7.7 13.2 8.8 13.2 H15.2 Q16.3 13.2 16.2 12.1 L15.7 8 C14.8 4.6 13.3 2.1 12 0.8 Z"/>
                <path d="M8.9 14.4 H15.1 L16.0 17.1 L17.0 19.2 V41.1 Q17.0 42.7 15.4 42.7 H8.6 Q7.0 42.7 7.0 41.1 V19.2 L8.0 17.1 Z"/>
                <path d="M6.4 43.6 H17.6 V45.8 H6.4 Z"/>
              </svg>)}
            </div>)}
          </div>
        </div>;
      })}
    </div>
  </div>;
}
